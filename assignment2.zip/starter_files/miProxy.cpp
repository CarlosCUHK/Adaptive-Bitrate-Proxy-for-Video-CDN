#include <arpa/inet.h> //close
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h> //strlen
#include <sys/socket.h>
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO, FD_SETSIZE macros
#include <sys/types.h>
#include <unistd.h> //close
#include <unordered_map>
#include <chrono>
#include <time.h>

using namespace std; 
using namespace chrono;
#define MAX_SIZE 1000000
#define TCP_PORT 80

int print_log(char* filename, char* log_message){
    FILE *fp;
    fp = fopen(filename, "w+");
    if (fp == NULL){
        printf("Error: file opening");
        exit(EXIT_FAILURE);
    }
    fprintf(fp, "%s", log_message);
    fclose(fp);
    return 0;
}

int get_connect_to_server_socket(const char* hostname, int port){
    int socket = socket(AF_INET, SOCK_STREAM, 0);
    int yes = 1;
    struct sockaddr_in addr;
    if (server_socket <= 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }
    int success =
        setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    if (success < 0) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }
    struct hostent *host = gethostbyname(hostname);
    if (host == nullptr){
        perror( "%s: unknown host\n", hostname);
        return -1;
    }
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    memcpy(&(addr.sin_addr), host->h_addr, host->h_length);
    if (connect(socket, (struct sockaddr *) &addr, sizeof(addr)) == -1){
        perror("Error: failed to bind socket");
        return -1;
    }
    return socket;
}

int get_server_socket(struct sockaddr_in *address, int PORT) {
    int yes = 1;
    int server_socket;
    // create a master socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket <= 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // set master socket to allow multiple connections ,
    // this is just a good habit, it will work without this
    int success =
        setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    if (success < 0) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }

    // type of socket created
    address->sin_family = AF_INET;
    address->sin_addr.s_addr = INADDR_ANY;
    address->sin_port = htons(PORT);

    // bind the socket to localhost port 8888
    success = bind(server_socket, (struct sockaddr *)address, sizeof(*address));
    if (success < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    printf("---Listening on port %d---\n", PORT);

    // try to specify maximum of 3 pending connections for the server socket
    if (listen(server_socket, 3) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }
    return server_socket;
}
struct Client_Socket_Info{
    string ip_address;
    int bitrate_choice[30];
    bool request_f4m;
    char chunkname[100];
    bool request_video;
    char f4m_file[2000];
    int bitrate_choice_num;
    int bitrate_curr;
    bool connect_to_server;
    int server_socket;
};

struct Server_Socket_Info{
    int corresponding_client;
};
void miProxy(int listen_port, char* www_ip, float alpha, char* log_path){
    int master_socket, addrlen, activity, valread;
    double T_avg = 0; 
    unordered_map<int, Client_Socket_Info> client_sockets;
    unordered_map<int, Server_Socket_Info> server_sockets;
    char log_message[100000];
    double T_curr = 0;
    log_message[0] = '\0';
    struct sockaddr_in address;
    master_socket = get_server_socket(&address, listen_port);

    char buffer[MAX_SIZE]; // data buffer of 1KiB + 1 bytes
    // accept the incoming connection
    addrlen = sizeof(address);
    puts("Waiting for connections ...");
    // set of socket descriptors
    fd_set readfds;
    while (1) {
        // clear the socket set
        FD_ZERO(&readfds);

        // add master socket to set
        FD_SET(master_socket, &readfds);
        for (auto &client_socket : client_sockets)
            FD_SET(client_socket.first, &readfds);

        for (auto &server_socket : server_sockets)
            FD_SET(server_socket.first, &readfds);

        // wait for an activity on one of the sockets , timeout is NULL ,
        // so wait indefinitely
        activity = select(FD_SETSIZE, &readfds, NULL, NULL, NULL);
        if ((activity < 0) && (errno != EINTR)) {
            perror("select error");
        }

        // If something happened on the master socket ,
        // then its an incoming connection, call accept()
        if (FD_ISSET(master_socket, &readfds)) {
            int new_socket = accept(master_socket, (struct sockaddr *)&address,
                                    (socklen_t *)&addrlen);
            if (new_socket < 0) {
                perror("accept");
                exit(EXIT_FAILURE);
            }
            struct Client_Socket_Info tmp_client;
            tmp_client.ip_address = inet_ntoa(address.sin_addr);
            tmp_client.connect_to_server = false;
            tmp_client.request_f4m = false;
            tmp_client.request_video = false;
            client_sockets[new_socket] = tmp_client;
            // inform user of socket number - used in send and receive commands
            printf("\n---New host connection---\n");
            printf("socket fd is %d , ip is : %s , port : %d \n", new_socket,
                    inet_ntoa(address.sin_addr), ntohs(address.sin_port));

            // send new connection greeting message
            // TODO: REMOVE THIS CALL TO SEND WHEN DOING THE ASSIGNMENT.

            // add new socket to the array of sockets
            for (int i = 0; i < MAXCLIENTS; i++) {
                // if position is empty
                if (client_sockets[i] == 0) {
                client_sockets[i] = new_socket;
                break;
                }
            }
        }
        // else it's some IO operation on a client socket
        for (auto & client_sock : client_sockets) {
            // Note: sd == 0 is our default here by fd 0 is actually stdin
            if (FD_ISSET(client_sock.first, &readfds)) {
                // Check if it was for closing , and also read the
                // incoming message
                getpeername(client_sock.first, (struct sockaddr *)&address,
                            (socklen_t *)&addrlen);
                valread = read(client_sock.first, buffer, MAX_SIZE);
                if (!client_sockets[client_sock.first].connect_to_server){
                    struct Server_Socket_Info tmp_server;
                    int tmp_server_socket = get_connect_to_server_socket(www_ip, 80);
                    tmp_server.corresponding_client = client_sock.first;
                    client_sockets[client_sock.first].server_socket = tmp_server_socket;
                    client_sockets[client_sock.first].connect_to_server = true;
                    server_sockets[tmp_server_socket] = tmp_server;
                }
                if (valread == 0) {
                    print_log(log_path,log_message);
                    // Somebody disconnected , get their details and print
                    printf("\n---Host disconnected---\n");
                    printf("Host disconnected , ip %s , port %d \n",
                            inet_ntoa(address.sin_addr), ntohs(address.sin_port));
                    // Close the socket and mark as 0 in list for reuse
                    close(client_sock.first);
                    client_sockets.erase(client_sock.first);
                } else {
                    // send the same message back to the client, hence why it's called
                    // "echo_server"
                    char first_line[80];
                    char remaining[2000];

                    buffer[valread] = '\0';
                    printf("\n---New message---\n");
                    printf("Message %s", buffer);
                    printf("Received from: ip %s , port %d \n",
                            inet_ntoa(address.sin_addr), ntohs(address.sin_port));
                    sscanf(buffer, "%s", first_line);
                    char *token = strtok(buffer, "\n");
                    strcpy(remaining, buffer);
                    if (strstr(first_line,"Seg"))
                    {   
                        client_sockets[client_sock.first].request_video = true;
                        client_sockets[client_sock.first].request_f4m = false;
                        int j;
                        char url[50], method[10], version[20];
                        char path[50];
                        char chunk_name[50];
                        sscanf(first_line, "%s %s %s", method, url, version);
                        sscanf(url, "%[^0-9]%*d%s", path, chunk_name);
                        strcpy(client_sockets[client_sock.first].chunkname, chunk_name);
                        for (j = 0; j < client_sockets[client_sock.first].bitrate_choice_num; j++)
                            if (T_avg < 1.5 * client_sockets[client_sock.first].bitrate_choice[j])
                                break;
                        if (j == 0)
                            client_sockets[client_sock.first].bitrate_curr = client_sockets[client_sock.first].bitrate_choice[0];
                        else
                            client_sockets[client_sock.first].bitrate_curr = client_sockets[client_sock.first].bitrate_choice[j-1];
                        char last_seg[50];
                        char first_seg[50];
                        sscanf(first_line, "%[^0-9]%*d%s", first_seg, last_seg);
                        char new_line[1500];
                        sprintf(new_line, "%s%d%s\r\n", first_seg, client_sockets[client_sock.first].bitrate_curr, last_seg);
                        strcat(new_line, remaining);
                        if (send(client_sockets[client_sock.first].server_socket, new_line, MAX_SIZE, 0) == -1){
                            printf("Error sending on stream socket\n");
                            return -1;
                        }
                    }
                    else if (strstr(first_line,"f4m")){
                        client_sockets[client_sock.first].request_video = false;
                        client_sockets[client_sock.first].request_f4m = true;
                        char url[50], method[10], version[20];
                        char path[50];
                        char new_line[1000];
                        sscanf(first_line, "%s %s %s", method, url, version);
                        sscanf(url, "%[^.].%*s", path);
                        strcat(path, "_nolist.f4m");
                        sprintf(new_line, "%s %s %s", method, path, version);
                        strcat(new_line, remaining);
                        strcpy(client_sockets[client_sock.first].f4m_file, new_line);
                        if (send(client_sockets[client_sock.first].server_socket, buffer, MAX_SIZE, 0) == -1){
                            printf("Error sending on stream socket\n");
                            return -1;
                        }
                    }
                    else {
                        client_sockets[client_sock.first].request_video = false;
                        client_sockets[client_sock.first].request_f4m = false;
                        if (send(client_sockets[client_sock.first].server_socket, buffer, MAX_SIZE, 0) == -1){
                            printf("Error sending on stream socket\n");
                            return -1;
                        }
                    }
                }
            }
        }
        for (auto & server_sock : server_sockets) {
            if (FD_ISSET(server_sock.first, &readfds)) {
                // Check if it was for closing , and also read the
                // incoming message
                getpeername(server_sock.first, (struct sockaddr *)&address,
                            (socklen_t *)&addrlen);
                valread = read(server_sock.first, buffer, MAX_SIZE);
                if (valread == 0) {
                    // Somebody disconnected , get their details and print
                    printf("\n---Host disconnected---\n");
                    printf("Host disconnected , ip %s , port %d \n",
                            inet_ntoa(address.sin_addr), ntohs(address.sin_port));
                    // Close the socket and mark as 0 in list for reuse
                    close(server_sock.first);
                    client_sockets.erase(server_sock.first);
                } else {
                    auto start = system_clock::now();
                    int bytes_read = 0;
                    int content_length = 0;
                    bytes_read = read(server_sock.first, buffer, MAX_SIZE);
                    char * full_chunk[MAX_SIZE] = {};
                    char *pos = strstr(buffer, "Content Length");
                    sscanf(&buffer[pos-buffer], "Content Length: %d", &content_length);
                    pos = strstr(buffer, "\r\n\r\n");
                    int content_remain = content_length - (bytes_read-(pos-buffer+4));
                    char* tmp_buff = buffer + bytes_read;
                    while (content_remain > 0){
                        int bytes_read1;
                        bytes_read1 = read(server_sock.first, tmp_buff, content_remain);
                        content_remain -= bytes_read1;
                        tmp_buff += bytes_read1;
                        bytes_read += bytes_read1;
                    }
                    // printf("\n---New message---\n");
                    // printf("Message %s", buffer);
                    // printf("Received from: ip %s , port %d \n",
                    //         inet_ntoa(address.sin_addr), ntohs(address.sin_port));
                    if (client_sockets[server_sockets[server_sock.first].corresponding_client].request_f4m)
                    {   
                        while(true){
                            char* token = strtok(buffer, "\n");
                            int tmp;
                            if (strstr(token, "bitrate="))
                            {
                                sscanf(token, " bitrate=\"%d\" ", &tmp);
                                client_sockets[server_sockets[server_sock.first].corresponding_client].bitrate_choice[client_sockets[server_sockets[server_sock.first].corresponding_client].bitrate_choice_num++] = tmp;                                
                            }
                            if (strstr(token, "</manifest>"))
                                break;
                        }
                        send(server_sock.first, client_sockets[server_sockets[server_sock.first].corresponding_client].f4m_file, MAX_SIZE, 0);
                        client_sockets[server_sockets[server_sock.first].corresponding_client].request_f4m = false;
                    }
                    if (client_sockets[server_sockets[server_sock.first].corresponding_client].request_video){
                        double time = duration_cast<microseconds>(system_clock::now()-start).count()/1000000.0;
                        T_curr = bytes_read/(time*1000);
                        T_avg = alpha * T_curr + (1 - alpha) * T_avg;
                        sprintf(log_message+strlen(log_message), "%s %s %s %d %d %d %d", client_sockets[server_sockets[server_sock.first].corresponding_client].ip_address,
                        client_sockets[server_sockets[server_sock.first].corresponding_client].chunkname,
                        www_ip, int(time), int(T_curr), int(T_avg), client_sockets[server_sockets[server_sock.first].corresponding_client].bitrate_curr);
                    }
                    if (send(client_sockets[server_sockets[server_sock.first].corresponding_client], buffer, MAX_SIZE, 0) == -1){
                        printf("Error sending on stream socket\n");
                        return -1;
                    }                    
                }
            }
        }
    }
}


int main(int argc, const char **argv){
    int listen_port;
    float alpha;
    char www_ip[40];
    char log_path[40];
    if (argc == 5){
        listen_port = atoi(argv[1]);
        if (listen_port < 1024 || listen_port > 65535){
            printf("Error: port number must be in the range of [1024, 65535]\n");
            exit(0);
        }
        strcpy(www_ip, argv[2]);
        alpha = atof(argv[3]);
        if (alpha < 0 || alpha > 1){
            printf("Error: alpha must be in the range of [0, 1]\n");
            exit(0);
        }
        strcpy(log_path, argv[4]);
        miProxy(listen_port, www_ip, alpha, log_path);
    }
    else if (argc == 6){
        if (!strcmp(argv[1], "--nodns")){
            printf("Error: nodns parameter\n");
            exit(0);
        }
        listen_port = atoi(argv[2]);
        if (listen_port < 1024 || listen_port > 65535){
            printf("Error: port number must be in the range of [1024, 65535]\n");
            exit(0);
        }
        strcpy(www_ip, argv[3]);
        alpha = atof(argv[4]);
        if (alpha < 0 || alpha > 1){
            printf("Error: alpha must be in the range of [0, 1]\n");
            exit(0);
        }
        strcpy(log_path, argv[5]);
    }
    else {
       printf("Error: missing or extra arguments\n");
       exit(0);
    }
} 